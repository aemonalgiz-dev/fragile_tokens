"""Is glitch-token damage MASKED in short completions and AMPLIFIED under long
self-conditioned generation?

Field reports say the effect shows up in reasoning models and in reasoning mode,
and is easy to miss otherwise. Everything measured in this project so far --
here and in the published detectors -- lives in the masked regime: one forward
pass, one token, a handful of predicted tokens. forward_geom.py found the
token's identity linearly recoverable at every layer for verified glitch tokens,
which is a real null and exactly what "masked in a standard completion" predicts.

Long generation is a different object. The model conditions on its own output,
so a small perturbation at step 0 is re-encoded at every subsequent step. Three
things could happen, and they are distinguishable:

  DAMPED       the chain recovers; per-step entropy converges to the healthy
               chain. Then reasoning mode is irrelevant and the field reports
               are about prompt phrasing.
  AMPLIFIED    the glitch/healthy entropy gap WIDENS with generated length.
  ATTRACTOR    chains seeded by DIFFERENT glitch tokens converge on each other
               in representation space, while healthy-seeded chains stay apart.
               This is the geometric version of the claim, and it is what
               "spews word fragments in a wide variety of languages" would look
               like from the inside: the chain has fallen into a common
               high-entropy basin that carries no seed identity.

The design holds the model fixed and varies only the regime, because comparing a
reasoning model to a non-reasoning model confounds regime with everything else
about the two models. Same weights, same tokens, same seeds:

  COMPLETION   short continuation, 8 tokens.
  REASONING    a chat-formatted prompt that asks the model to identify and
               reason about the token, 256 tokens.

Seed token ids are spliced in DIRECTLY. segmentation.py shows a leading space
re-segments ~90% of tokens regardless of health, so building these prompts as
strings would silently replace the token under test.

Convergence is measured on centred last-layer states: the residual stream has a
large shared component, and without centring every pair of chains looks
identical at every step.
"""
from __future__ import annotations
import argparse, gzip, json, unicodedata
from pathlib import Path
import numpy as np
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer

STEPS = [1, 2, 4, 8, 16, 32, 64, 128, 192, 255]


def load_verified(path, n):
    ver = np.zeros(n, int); tested = np.zeros(n, bool)
    for line in gzip.open(path, "rt", encoding="utf-8"):
        r = json.loads(line); i = int(r["i"])
        if i < n and "magikarp" in r:
            tested[i] = True
            if "verified" in r["magikarp"]:
                ver[i] = 1
    return ver, tested


def build(tok, t, regime):
    """Prompt ids with token id t spliced in directly (never via encode(str))."""
    e = lambda s: tok(s, add_special_tokens=False)["input_ids"]
    if regime == "completion":
        return e("The word") + [t]
    head = ("<|user|>\nWhat is this token? Identify it exactly, then explain "
            "step by step what it means:")
    tail = "\n<|assistant|>\nLet me think about this carefully."
    try:                                    # prefer the model's real template
        msgs = [{"role": "user", "content": "\x00"}]
        s = tok.apply_chat_template(msgs, tokenize=False, add_generation_prompt=True)
        a, b = s.split("\x00")
        return e(a) + [t] + e(b + "Let me think about this carefully.")
    except Exception:
        return e(head) + [t] + e(tail)


@torch.no_grad()
def run(model, tok, dev, ids_list, max_new):
    """Greedy-generate, then one forward pass to recover per-step entropy and
    last-layer states. Greedy keeps the comparison deterministic; sampling noise
    at 256 steps would swamp a group difference this size."""
    gens, ents, Hs = [], [], []
    for ids in ids_list:
        p = torch.tensor(ids, device=dev).unsqueeze(0)
        # min_new_tokens forces every chain to the same length. Without it a
        # chain that emits EOS at step 1 is silently one step long, and the
        # per-step comparison is between chains of different ages. EOS is
        # suppressed rather than merely un-stopped so it cannot dominate the
        # distribution and flatten the entropy curve.
        out = model.generate(p, max_new_tokens=max_new, min_new_tokens=max_new,
                             do_sample=False, pad_token_id=tok.eos_token_id or 0,
                             suppress_tokens=[tok.eos_token_id] if tok.eos_token_id
                             is not None else None)
        full = out[0]
        gens.append(full[p.shape[1]:].tolist())
        o = model(input_ids=full.unsqueeze(0), output_hidden_states=True)
        lg = o.logits[0, p.shape[1] - 1:-1].float()
        lp = torch.log_softmax(lg, -1)
        ents.append((-(lp.exp() * lp).sum(-1)).cpu().numpy())
        Hs.append(o.hidden_states[-1][0, p.shape[1]:].float().cpu().half())
    return gens, ents, Hs


def pcos(H):
    """Mean pairwise cosine of centred vectors, minus the -1/(n-1) floor that a
    centred set has by construction. 0 = no more aligned than chance."""
    n = H.shape[0]
    if n < 3:
        return float("nan")
    X = (H - H.mean(0, keepdim=True)).float()
    X = X / (X.norm(dim=-1, keepdim=True) + 1e-9)
    G = X @ X.T
    return float((G.sum() - n) / (n * (n - 1))) + 1.0 / (n - 1)


def scripts(s):
    out = set()
    for c in s:
        if c.isspace() or not c.isalpha():
            continue
        try:
            out.add(unicodedata.name(c).split()[0])
        except ValueError:
            out.add("UNNAMED")
    return out


def rep_rate(g):
    if len(g) < 4:
        return float("nan")
    return 1.0 - len(set(g)) / len(g)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", default="allenai/OLMo-2-1124-7B-Instruct")
    ap.add_argument("--ext", default="external/allenai_OLMo_2_1124_7B.jsonl.gz")
    ap.add_argument("--n", type=int, default=32)
    ap.add_argument("--max-new", type=int, default=256)
    ap.add_argument("--out", default="results/reasoning_drift.json")
    a = ap.parse_args()

    dev = "cuda" if torch.cuda.is_available() else "cpu"
    tok = AutoTokenizer.from_pretrained(a.model)
    model = AutoModelForCausalLM.from_pretrained(
        a.model, dtype=torch.float16 if dev == "cuda" else torch.float32).to(dev).eval()
    V = model.get_input_embeddings().weight.shape[0]
    ver, tested = load_verified(a.ext, V)

    rng = np.random.default_rng(0)
    pos = [int(i) for i in np.where(ver == 1)[0]]
    rng.shuffle(pos); pos = pos[:a.n]
    negpool = np.where((ver == 0) & tested)[0]
    neg = [int(i) for i in rng.choice(negpool, size=len(pos), replace=False)]
    allids = pos + neg
    grp = {"glitch": np.arange(len(pos)),
           "healthy": np.arange(len(pos), len(allids))}
    print(f"{a.model}: {len(pos)} glitch vs {len(neg)} healthy, {dev}")
    print("  glitch:", [repr(tok.decode([t]))[:14] for t in pos[:6]])
    print("  healthy:", [repr(tok.decode([t]))[:14] for t in neg[:6]])

    report = {"model": a.model, "n": len(pos)}
    for regime, mx in [("completion", 8), ("reasoning", a.max_new)]:
        print()
        print("=" * 74)
        print(f"REGIME: {regime}   ({mx} generated tokens)")
        print("=" * 74)
        seqs = [build(tok, t, regime) for t in allids]
        gens, ents, Hs = run(model, tok, dev, seqs, mx)

        print(f"{'step':>6} | {'entropy gl':>10} {'entropy he':>10} {'gap':>7} | "
              f"{'pcos gl':>8} {'pcos he':>8}")
        print("-" * 60)
        rows = []
        for s in [x for x in STEPS if x <= mx]:
            eg = np.mean([ents[i][s - 1] for i in grp["glitch"]])
            eh = np.mean([ents[i][s - 1] for i in grp["healthy"]])
            Hg = torch.stack([Hs[i][s - 1] for i in grp["glitch"]])
            Hh = torch.stack([Hs[i][s - 1] for i in grp["healthy"]])
            # centre across ALL chains at this step, then measure within-group
            allH = torch.cat([Hg, Hh]); mu = allH.float().mean(0, keepdim=True)
            r = {"step": s, "ent_g": float(eg), "ent_h": float(eh),
                 "gap": float(eg - eh),
                 "pcos_g": pcos(Hg.float() - mu), "pcos_h": pcos(Hh.float() - mu)}
            rows.append(r)
            print(f"{s:6d} | {eg:10.3f} {eh:10.3f} {r['gap']:7.3f} | "
                  f"{r['pcos_g']:8.4f} {r['pcos_h']:8.4f}")

        txt = [tok.decode(g) for g in gens]
        sg = np.mean([len(scripts(txt[i])) for i in grp["glitch"]])
        sh = np.mean([len(scripts(txt[i])) for i in grp["healthy"]])
        rg = np.mean([rep_rate(gens[i]) for i in grp["glitch"]])
        rh = np.mean([rep_rate(gens[i]) for i in grp["healthy"]])
        selfg = np.mean([allids[i] in gens[i] for i in grp["glitch"]])
        selfh = np.mean([allids[i] in gens[i] for i in grp["healthy"]])
        print(f"\n  distinct scripts in output : glitch {sg:.2f}  healthy {sh:.2f}")
        print(f"  token-repetition rate      : glitch {rg:.3f}  healthy {rh:.3f}")
        print(f"  reproduced the seed token  : glitch {selfg:.3f}  healthy {selfh:.3f}")
        report[regime] = {"rows": rows, "scripts": [sg, sh], "rep": [rg, rh],
                          "self": [float(selfg), float(selfh)]}

        print(f"\n  --- sample generations ({regime}) ---")
        for lab, idx in [("GLITCH", grp["glitch"][:3]), ("HEALTHY", grp["healthy"][:2])]:
            for i in idx:
                print(f"  [{lab}] {tok.decode([allids[i]])!r} -> "
                      f"{txt[i][:160].encode('unicode_escape').decode()!r}")
        report[regime]["samples"] = [
            {"group": "glitch" if i in grp["glitch"] else "healthy",
             "tok": tok.decode([allids[i]]), "gen": txt[i][:400]}
            for i in list(grp["glitch"][:8]) + list(grp["healthy"][:8])]

    print()
    print("=" * 74)
    print("MASKING TEST: does the glitch/healthy gap grow from completion to")
    print("reasoning, and does the glitch group converge as the chain runs?")
    print("=" * 74)
    c, r = report["completion"]["rows"], report["reasoning"]["rows"]
    print(f"  entropy gap, completion  @step8   {c[-1]['gap']:+.3f}")
    print(f"  entropy gap, reasoning   @step8   "
          f"{[x for x in r if x['step']==8][0]['gap']:+.3f}")
    print(f"  entropy gap, reasoning   @step{r[-1]['step']} {r[-1]['gap']:+.3f}")
    print(f"  glitch chain alignment,  step1 -> step{r[-1]['step']}   "
          f"{r[0]['pcos_g']:.4f} -> {r[-1]['pcos_g']:.4f}")
    print(f"  healthy chain alignment, step1 -> step{r[-1]['step']}   "
          f"{r[0]['pcos_h']:.4f} -> {r[-1]['pcos_h']:.4f}")

    Path(a.out).parent.mkdir(parents=True, exist_ok=True)
    json.dump(report, open(a.out, "w"), indent=1)
    print(f"\nsaved -> {a.out}")


if __name__ == "__main__":
    main()
